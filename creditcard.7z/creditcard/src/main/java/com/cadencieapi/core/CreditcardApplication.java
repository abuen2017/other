package com.cadencieapi.core;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = {"com.cadencieapi"})
public class CreditcardApplication 
{

	public static void main(String[] args) 
	{
		SpringApplication.run(CreditcardApplication.class, args);
	}

}
