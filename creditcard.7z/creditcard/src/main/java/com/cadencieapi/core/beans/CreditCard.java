package com.cadencieapi.core.beans;

public class CreditCard 
{
	String cardNumber;
	String cancelCode;
	
	public String getCardNumber() 
	{
		return cardNumber;
	}
	
	public void setCardNumber(String cardNumber) 
	{
		this.cardNumber = cardNumber;
	}
	
	public String getCancelCode() 
	{
		return cancelCode;
	}
	
	public void setCancelCode(String cancelCode) 
	{
		this.cancelCode = cancelCode;
	}
	
	
}
