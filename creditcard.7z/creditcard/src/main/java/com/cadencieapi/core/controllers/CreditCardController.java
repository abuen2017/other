package com.cadencieapi.core.controllers;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cadencieapi.core.beans.CreditCard;
import com.cadencieapi.core.dao.CreditCardDAO;

@Controller
public class CreditCardController
{
	  @RequestMapping(method = RequestMethod.GET, value="/creditcard")
	  
	  @ResponseBody
	  public List<CreditCard> getAllCreditCards() 
	  {
		  
		  return new CreditCardDAO().getCreditCards();
	  }

}
