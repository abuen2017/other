package com.cadencieapi.core.dao;

import java.util.ArrayList;
import java.util.List;

import com.cadencieapi.core.beans.CreditCard;

public class CreditCardDAO 
{
	public List<CreditCard> getCreditCards()
	{
		List ccList = new ArrayList();
		
		CreditCard cc1 = new CreditCard();
		cc1.setCardNumber("512512345000");
		cc1.setCancelCode("R");
		
		
		CreditCard cc2 = new CreditCard();
		cc1.setCardNumber("514412345000");
		cc1.setCancelCode("B");
		
		ccList.add(cc1);
		ccList.add(cc2);
		
		return ccList;
	}
}
